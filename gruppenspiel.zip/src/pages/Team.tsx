function Team() {
  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>👥 Team View</h1>
      <p>This is a placeholder for the team view.</p>
    </div>
  )
}

export default Team
